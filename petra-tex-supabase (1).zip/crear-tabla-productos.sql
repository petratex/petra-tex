-- ============================================================
-- PETRA TEX — Script para crear la tabla de productos en Supabase
-- ============================================================
-- Cómo usarlo:
-- 1. Entra en tu proyecto de Supabase (supabase.com)
-- 2. En el menú de la izquierda, pulsa "SQL Editor"
-- 3. Pulsa "New query"
-- 4. Pega TODO este archivo
-- 5. Pulsa "Run" (o Ctrl+Enter)
-- ============================================================

-- Tabla donde se guardará cada prenda de la tienda
create table if not exists products (
  id text primary key,
  data jsonb not null,
  updated_at timestamptz not null default now()
);

-- Activamos la seguridad a nivel de fila (obligatorio en Supabase)
alter table products enable row level security;

-- Permitimos que el catálogo (clientes) pueda LEER los productos
create policy if not exists "Cualquiera puede leer productos"
on products for select
to anon
using (true);

-- Permitimos que el panel de administración pueda AÑADIR productos
create policy if not exists "Cualquiera puede añadir productos"
on products for insert
to anon
with check (true);

-- Permitimos que el panel de administración pueda EDITAR productos
create policy if not exists "Cualquiera puede editar productos"
on products for update
to anon
using (true)
with check (true);

-- Permitimos que el panel de administración pueda BORRAR productos
create policy if not exists "Cualquiera puede borrar productos"
on products for delete
to anon
using (true);

-- Nota de seguridad: estas políticas están abiertas (sin usuario/contraseña propios de Supabase)
-- porque el panel admin ya está protegido con la contraseña que ya tiene tu tienda.
-- Es el mismo nivel de protección que tenías hasta ahora, solo que los datos ahora
-- viven en la nube en lugar del navegador.
